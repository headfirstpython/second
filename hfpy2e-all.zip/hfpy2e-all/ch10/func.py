

def apply(func: object, value: object) -> object:
    return func(value)

